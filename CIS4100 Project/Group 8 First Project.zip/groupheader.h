/* Madyan Hussain
   header file
   we create a header file to link all the function and make them accessable for main.
   all the prototypes for the function are in this file
*/
#ifndef GROUPHEADER_H_
#define GROUPHEADER_H_

double fa(double amount);// prototype for the first function
double fb(double amount);// prototype for the second function
double fc(double amount);// prototype for the third function
double fd(double amount);// prototype for the fourth function
double ff(double amount);// prototype for the fifth function
#endif /* GROUPHEADER_H_ */